package com.theapache64.jabroid.data.repositories

import androidx.lifecycle.LiveData
import com.theapache64.twinkill.network.utils.Resource
import com.theapache64.jabroid.data.remote.ApiInterface
import com.theapache64.jabroid.data.remote.login.LogInRequest
import com.theapache64.jabroid.data.remote.login.LogInResponse
import javax.inject.Inject
import javax.inject.Singleton


@Singleton
class AuthRepository @Inject constructor(
    private val apiInterface: ApiInterface
) {

    /**
     * To do API call to login route
     */
    fun login(logInRequest: LogInRequest): LiveData<Resource<LogInResponse>> {
        return apiInterface.login(logInRequest)
    }
}