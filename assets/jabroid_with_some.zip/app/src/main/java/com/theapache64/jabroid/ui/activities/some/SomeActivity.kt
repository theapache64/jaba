package com.theapache64.jabroid.ui.activities.some

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.theapache64.jabroid.R

class SomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_some)
    }
}
