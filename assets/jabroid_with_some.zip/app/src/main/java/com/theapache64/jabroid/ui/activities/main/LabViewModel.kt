package com.theapache64.jabroid.ui.activities.main


import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.theapache64.jabroid.data.repositories.UserPrefRepository
import javax.inject.Inject

class LabViewModel @Inject constructor(
    private val userPrefRepository: UserPrefRepository
) : ViewModel() {

    
private val isLoggedOut = MutableLiveData<Boolean>()
fun getLoggedOut(): LiveData<Boolean> = isLoggedOut

/**
 * Clears preference and logout user
 */
fun logout() {
    userPrefRepository.clearUser()
    isLoggedOut.value = true
}

}