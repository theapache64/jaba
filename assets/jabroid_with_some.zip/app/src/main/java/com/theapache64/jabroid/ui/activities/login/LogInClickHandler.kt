package com.theapache64.jabroid.ui.activities.login

interface LogInClickHandler {
    fun onLogInClicked();
}