package com.theapache64.jabroid.di.modules

import com.theapache64.jabroid.ui.activities.login.LogInActivity
import com.theapache64.jabroid.ui.activities.main.LabActivity
import com.theapache64.jabroid.ui.activities.splash.SplashActivity
import dagger.Module
import dagger.android.ContributesAndroidInjector

/**
 * To hold activities to support AndroidInjection call from dagger.
 */
@Module
abstract class ActivitiesBuilderModule {

    
@ContributesAndroidInjector
abstract fun getSplashActivity(): SplashActivity


    
@ContributesAndroidInjector
abstract fun getLogInActivity(): LogInActivity


    @ContributesAndroidInjector
    abstract fun getLabActivity(): LabActivity
}