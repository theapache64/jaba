package com.theapache64.jabroid.ui.activities.splash

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.theapache64.twinkill.utils.livedata.SingleLiveEvent

import com.theapache64.jabroid.data.repositories.UserPrefRepository
import com.theapache64.jabroid.ui.activities.login.LogInActivity

import com.theapache64.jabroid.ui.activities.main.LabActivity
import com.theapache64.jabroid.BuildConfig
import javax.inject.Inject

class SplashViewModel @Inject constructor(
     private val userPrefRepository: UserPrefRepository
) : ViewModel() {

    val versionName = "v${BuildConfig.VERSION_NAME}"

    private val launchActivityEvent = SingleLiveEvent<Int>()

    fun getLaunchActivityEvent(): LiveData<Int> {
        return launchActivityEvent
    }

    fun goToNextScreen() {

        
// if theUser == null -> login else main
val user = userPrefRepository.getUser()
val activityId = if (user == null) LogInActivity.ID else LabActivity.ID

Log.i(TAG, "User is ${user?.name}")


        // passing id with the finish notification
        launchActivityEvent.notifyFinished(activityId)
    }

    companion object {
        val TAG = SplashViewModel::class.java.simpleName
    }

}