package com.theapache64.jabroid.data.remote


import androidx.lifecycle.LiveData
import com.theapache64.jabroid.data.remote.login.LogInRequest
import com.theapache64.jabroid.data.remote.login.LogInResponse
import com.theapache64.twinkill.network.utils.Resource
import retrofit2.http.Body
import retrofit2.http.POST


/**
 * To hold all API methods
 */
interface ApiInterface {
    
 @POST("login")
fun login(@Body logInRequest: LogInRequest): LiveData<Resource<LogInResponse>>

}

